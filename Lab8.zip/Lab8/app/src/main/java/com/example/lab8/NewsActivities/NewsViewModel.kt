package com.example.lab8.NewsActivities

import androidx.lifecycle.ViewModel

class NewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}