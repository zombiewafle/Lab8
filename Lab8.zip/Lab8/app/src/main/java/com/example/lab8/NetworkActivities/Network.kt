package com.example.lab8.NetworkActivities

data class Network(
    val id: Int,
    val name: String,
    val descp: String,
    val url: String
)